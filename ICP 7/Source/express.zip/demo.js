var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var port = process.env.PORT || 3000;

var mongoose = require('mongoose');

mongoose
  .connect('mongodb+srv://test_user:test@cluster0.ycuzp.mongodb.net/library?retryWrites=true&w=majority', { useNewUrlParser: true })
  .then(() => console.log("Conected to MogonDB"))
  .catch(err => console.log("Error in connectin to MongoDB"));


var BookSchema = new mongoose.Schema({
  isbn: String,
  title: String,
  author: String,
  description: String,
  published_year: String,
  publisher: String,
  updated_date: {type: Date, default: Date.now},
});

Book = mongoose.model('Book', BookSchema);

app.use(express.json())

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*"); // update to match the domain you will make the request from
    res.header("Access-Control-Allow-Headers", "*");
    res.header("Access-Control-Request-Method", "GET,PUT,POST,DELETE");
    next();
  });

app.get('/', function (req, res) {
    res.send('<html><head> </head><body><h1>Hello World!!!</h1></body></html>');
});

app.get('/api', function (req, res) {
    res.json({'firstName': "Vijaya", 'lastName': "Yeruva"});
});

app.get('/testbook', function (req, res, next) {
    res.json({test:'Working'})
  });

// var router = express.Router();
// var Book = require('../models/Book.js');

/* GET ALL BOOKS */
app.get('/getbooks', function (req, res, next) {
  Book.find(function (err, products) {
    if (err) return next(err);
    res.json(products);
  });
});

/* GET SINGLE BOOK BY ID */
app.get('/getbook/:id', function (req, res, next) {
  Book.findById(req.params.id, function (err, post) {
    if (err) return next(err);
    res.json(post);
  });
});

/* SAVE BOOK */
app.post('/savebook', function (req, res, next) {
  Book.create(req.body, function (err, post) {
    if (err) return next(err);
    res.json(post);
  });
});



/* UPDATE BOOK */
app.put('/updatebook/:id', function(req,res,next){
    console.log('Update query@@@@@@@@@@', req.params);
    console.log("Update body@@@@@@@@@@@", req.body);
    Book.findOneAndUpdate(req.params.id, req.body, function(err, response){
        if(err) return next(err);
        res.json(response);
    });
});

/* DELETE BOOK */
app.delete('/deletebook/:id', function(req, res, next){
    console.log('delete body......@@@', req.params.id);
    Book.findOneAndDelete(req.params.id, function(err, response){
        if(err) return next(err);
        res.json(response);
    });
});

app.listen(port);
console.log('Server running at http://localhost:3000');
